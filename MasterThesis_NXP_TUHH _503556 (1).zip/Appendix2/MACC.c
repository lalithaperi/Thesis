#define macc(accm, multiplier, multiplicand)   
  asm volatile("macc %0, %1, %2"   
               : "+r"(accm)    
               : "r"(multiplier), "r"(multiplicand)   );
               
void biginth_mulmodmontCIOSOptimised(DATATYPE *const out,
                                     const DATATYPE x,
                                     const DATATYPE y,
                                     const DATATYPE m) 
{
    volatile DATATYPE operand1[NUM_LIMBS], operand2[NUM_LIMBS], mod[NUM_LIMBS], A[NUM_LIMBS + 2],
             inv_lo = 0xDD0620222B, temp, A0inv, i , j;

    // Initialize arrays
    for (i = 0; i < NUM_LIMBS +2; i++) 
    {
        if(i < NUM_LIMBS)
        {
            operand1[i] = x;
            operand2[i] = y;
            mod[i] = m;
        }
        A[i] = 0;
    }

    for (i = 0; i < NUM_LIMBS; i++) 
    {
        //MAC Operation
        for (j = 0; j < NUM_LIMBS; j++) 
        {
            macc(A[j], operand1[i], operand2[j]);
        }

        // Propagate the carry to the last limb
        addc(A[NUM_LIMBS], A[NUM_LIMBS], 0);
        addc(A[NUM_LIMBS + 1], 0, 0);

        A0inv = A[0] * inv_lo;
        temp=A[0];
        macc(temp, A0inv, mod[0]);

        //Mongomery domain reduction
        for (j = 1; j < NUM_LIMBS; j++) 
        {
            temp = A[j];
            macc(temp, A0inv, mod[j]);
            A[j-1] = temp;
        }
        
        // Propagate the carry 
        addc(A[NUM_LIMBS - 1], A[NUM_LIMBS], 0);
        addc(A[NUM_LIMBS], A[NUM_LIMBS + 1], 0);
    }

    // copy to result
    for (i = 0; i < NUM_LIMBS; i++)
    {
	    out[i] = A[i];
    }

    // final subtraction, first see if necessary
    if (A[NUM_LIMBS] > 0 || biginth_less_than_or_equal(mod, out))
    {
        biginth_sub(out, out, mod);
    }
}